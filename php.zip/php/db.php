<?php
// Allow requests from the local Angular dev server and a production domain
$allowed_origins = [
    'http://localhost:4200', // For local development
    'https://your-frontend-domain.com' // For production
];

if (isset($_SERVER['HTTP_ORIGIN']) && in_array($_SERVER['HTTP_ORIGIN'], $allowed_origins)) {
    header("Access-Control-Allow-Origin: " . $_SERVER['HTTP_ORIGIN']);
} else {
    // Optionally, block requests from other origins
    header("Access-Control-Allow-Origin: https://your-frontend-domain.com");
}
header("Access-Control-Allow-Headers: *");

function getDbConnection() {
    // Lee las variables de entorno del archivo .env en la raíz del proyecto
    $envFile = __DIR__ . '/../../.env';
    if (!file_exists($envFile)) {
        die("Error: .env file not found.");
    }

    $env = parse_ini_file($envFile);

    $host = $env['MYSQL_HOST'];
    $user = $env['MYSQL_USER'];
    $password = $env['MYSQL_PASSWORD'];
    $database = $env['MYSQL_DATABASE'];

    $conn = new mysqli($host, $user, $password, $database);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    return $conn;
}
?>
