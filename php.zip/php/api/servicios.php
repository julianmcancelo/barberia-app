<?php
require_once '../db.php';

header('Content-Type: application/json');

$conn = getDbConnection();

$sql = "SELECT * FROM Servicios";
$result = $conn->query($sql);

$servicios = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        // Convertir los tipos de datos si es necesario para que coincidan con el JSON original
        $row['id'] = (int)$row['id'];
        $row['duracion'] = (int)$row['duracion'];
        $row['precio'] = (string)$row['precio']; // O float si se maneja como número
        $servicios[] = $row;
    }
}

$conn->close();

echo json_encode(['result' => $servicios]);
?>
