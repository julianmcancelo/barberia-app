<?php
require_once '../db.php';

header('Content-Type: application/json');

// Solo permitir peticiones POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
    exit;
}

// Leer el cuerpo de la petición
$data = json_decode(file_get_contents('php://input'), true);

$nombre_completo = $data['nombre_completo'] ?? null;
$email = $data['email'] ?? null;
$whatsapp = $data['whatsapp'] ?? null;
$servicio_id = $data['servicio_id'] ?? null;
$fecha_hora = $data['fecha_hora'] ?? null;

// Validación de campos
if (!$nombre_completo || !$email || !$servicio_id || !$fecha_hora) {
    http_response_code(400);
    echo json_encode(['error' => 'Faltan campos requeridos']);
    exit;
}

$conn = getDbConnection();
$conn->begin_transaction();

try {
    // 1. Buscar o crear el cliente
    $stmt = $conn->prepare('SELECT id FROM Clientes WHERE email = ?');
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $cliente = $result->fetch_assoc();

    $clienteId;
    if ($cliente) {
        $clienteId = $cliente['id'];
        $updateStmt = $conn->prepare('UPDATE Clientes SET nombre_completo = ?, whatsapp = ? WHERE id = ?');
        $updateStmt->bind_param('ssi', $nombre_completo, $whatsapp, $clienteId);
        $updateStmt->execute();
    } else {
        $insertStmt = $conn->prepare('INSERT INTO Clientes (nombre_completo, email, whatsapp) VALUES (?, ?, ?)');
        $insertStmt->bind_param('sss', $nombre_completo, $email, $whatsapp);
        $insertStmt->execute();
        $clienteId = $insertStmt->insert_id;
    }

    // 2. Generar un token único
    $token_reserva = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);

    // 3. Crear la reserva
    $reservaStmt = $conn->prepare('INSERT INTO Reservas (cliente_id, servicio_id, fecha_hora, token_reserva) VALUES (?, ?, ?, ?)');
    $reservaStmt->bind_param('iiss', $clienteId, $servicio_id, $fecha_hora, $token_reserva);
    $reservaStmt->execute();

    $conn->commit();

    // 4. Devolver el token como confirmación
    http_response_code(201);
    echo json_encode(['token_reserva' => $token_reserva]);

} catch (Exception $e) {
    $conn->rollback();
    http_response_code(500);
    echo json_encode(['error' => 'Error interno del servidor: ' . $e->getMessage()]);
} finally {
    if (isset($stmt)) $stmt->close();
    if (isset($updateStmt)) $updateStmt->close();
    if (isset($insertStmt)) $insertStmt->close();
    if (isset($reservaStmt)) $reservaStmt->close();
    $conn->close();
}
?>
